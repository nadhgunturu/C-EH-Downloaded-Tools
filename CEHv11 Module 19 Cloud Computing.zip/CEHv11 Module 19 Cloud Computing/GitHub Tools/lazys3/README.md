# lazys3

A Ruby script to bruteforce for AWS s3 buckets using different permutations.

# Usage 

```
$ ruby lazys3.rb <COMPANY> 
```

# Authors
- http://twitter.com/nahamsec
- http://twitter.com/JobertAbma

# Changelog 

1.0 - Release
